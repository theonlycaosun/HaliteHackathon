#include <stdlib.h>
#include <time.h>
#include <cstdlib>
#include <ctime>
#include <time.h>
#include <set>
#include <fstream>

#include "hlt.hpp"
#include "networking.hpp"

/*Site findClosestSite(Site origin)
{
    std::queue<Site> Q;
    std::vector<Site> children;
    string path = "";
    
    Q.push(origin);
    
    while(!Q.empty())
    {
        Site t = Q.front();
        path += t.getDistance();
        
        Q.pop();
        
        if(t == goal){
            return path;
        }
        children = t.getChildren();
        for (int i = 0; i < children.size(); ++i)
        {
            Q.push(children[i]);
        }
    }
    return path;
}*/


int main() {
    srand(time(NULL));

    std::cout.sync_with_stdio(0);

    unsigned char myID;
    hlt::GameMap presentMap;
    getInit(myID, presentMap);
    sendInit("MyC++Bot");

    std::set<hlt::Move> moves;
    while(true) {
        moves.clear();

        getFrame(presentMap);

        for(unsigned short a = 0; a < presentMap.height; a++) {
            for(unsigned short b = 0; b < presentMap.width; b++) {
                hlt::Location t;
                t.x = b;
                t.y = a;
    
                if (presentMap.getSite({ b, a }).owner == myID) {
                    for (unsigned char i = 0; i<5; i++) {
                        if(presentMap.getSite({b, a}).strength > presentMap.getSite(presentMap.getLocation(t, i)).strength && presentMap.getSite(presentMap.getLocation(t, i)).owner != myID) {
                            if (presentMap.getSite({b, a}).strength != 0) {
                            moves.insert( { {b,a}, i } );
                            }
                            else moves.insert( { {b,a}, 0 } );
                        }
                    }
                }
                    if (presentMap.getSite(presentMap.getLocation(t, 1)).owner == myID && presentMap.getSite(presentMap.getLocation(t, 2)).owner == myID && presentMap.getSite(presentMap.getLocation(t, 3)).owner == myID && presentMap.getSite(presentMap.getLocation(t, 4)).owner == myID) {
                        if (presentMap.getSite({b, a}).strength >= 30){
                                moves.insert({ {b,a}, (unsigned char)(rand()%2 + 1) });
                        }
                        else moves.insert({ {b,a}, 0 });
                    }
                    
//moves.insert({ { b, a }, (unsigned char)(rand() % 5) });
                    
                    
                    
                    
                    
                    
                    
                    
                    
                }
            }

        sendFrame(moves);
    }

    return 0;
}
